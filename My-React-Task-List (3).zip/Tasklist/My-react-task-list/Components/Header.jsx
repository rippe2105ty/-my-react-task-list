export default function Header(){
    return(
        <header>
            <h1>TODO APP</h1>
            <div>
                <input type="text" placeholder="Add a new task" style={{ marginRight: '8px' }}/>
                <button>Add</button>
            </div>
        </header>
    )
} 