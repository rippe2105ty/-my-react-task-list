// Task.jsx
import React from 'react';

export default function Task({ id, name, isComplete, onEdit, onDelete }) {
    return (
        <div style={{ display: 'flex', alignItems: 'center', margin: '8px 0' }}>
            <input type="checkbox" checked={isComplete} readOnly style={{ marginRight: '12px' }} />
            <span style={{ textDecoration: isComplete ? 'line-through' : 'none', flexGrow: 1 }}>
                {name}
            </span>
            <button onClick={() => onEdit(id)} style={{ marginRight: '8px' }}>Editar</button>
            <button onClick={() => onDelete(id)}>Eliminar</button>
        </div>
    );
}
