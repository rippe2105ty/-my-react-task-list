// TaskList.jsx
import React, { useState } from 'react';
import Task from './Task';

export default function TaskList() {
    const [tasks, setTasks] = useState([
        { id: 1, name: 'Buy a new gaming laptop', isComplete: false },
        { id: 2, name: 'Complete a previous task', isComplete: false },
        { id: 3, name: 'Create video for YouTube', isComplete: true },
        { id: 4, name: 'Create a new portfolio site', isComplete: true }
    ]);

    return (
        <section>
            {tasks.map(task => (
                <Task key={task.id} name={task.name} isComplete={task.isComplete} />
            ))}
        </section>
    );
}
